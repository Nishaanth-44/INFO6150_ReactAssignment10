export const data = [
    {
        alpha: "About our Leaderships",
        beta: "At Netflix, we want to entertain the world. Whatever your taste, and no matter where you live, we give you access to best-in-class TV series, documentaries, feature films and mobile games. Our members control what they want to watch, when they want it, with no ads, in one simple subscription. We’re streaming in more than 30 languages and 190 countries, because great stories can come from anywhere and be loved everywhere. We are the world’s biggest fans of entertainment, and we’re always looking to help you find your next favorite story."
    },

    {
        alpha: "History of Netflix",
        beta: "Netflix is one of the world's leading entertainment services with 223 million paid memberships in over 190 countries enjoying TV series, documentaries, feature films and mobile games across a wide variety of genres and languages. Members can play, pause and resume to watch, as much as they want, anytime, anywhere, and can change their plans at any time."
    },

    {
        alpha: "Profile of Netflix",
        beta: "At Netflix, we aspire to entertain the world—creating great stories from anywhere and offering greater choice and control for people everywhere. To help us succeed, we’ve created an unusual employee culture. This document is about that culture, and how we can continuously improve as a team so that we can better serve our members."
    }

]