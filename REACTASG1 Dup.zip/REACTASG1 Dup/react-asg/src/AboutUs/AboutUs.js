import React from 'react'
import Card from './AboutCardComp';
import {data} from './AboutData';


function AboutUs() {
    return (
       <><div><a href="./Home.js">Return To Home Page</a></div>
       <h1>This is AboutUs page</h1>
       {
        data.map((item) => {
            return (
                <Card {...item}></Card>
            )
        })
       }
       </>
    )

}

export default AboutUs