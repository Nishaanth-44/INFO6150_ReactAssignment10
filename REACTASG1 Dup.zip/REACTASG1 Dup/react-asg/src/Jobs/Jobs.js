import React from 'react'
import Card from './JobsCardComp';
import {data} from './JobsData';

function Jobs() {
    return (
        <>
        <div><a href="./Home.js">Return To Home Page</a></div>
        <h1>This is Jobs page</h1>
        {
        data.map((item) => {
            return (
                <Card {...item}></Card>
            )
        })
       }
        </>    
    )

}

export default Jobs