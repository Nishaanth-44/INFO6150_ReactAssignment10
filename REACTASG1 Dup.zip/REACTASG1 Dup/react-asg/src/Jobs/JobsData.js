export const data = [
    {
        alpha: "Available Jobs",
        beta: "We model ourselves on being a professional sports team, not a family. A family is about unconditional love. A dream team is about pushing yourself to be the best possible teammate, caring intensely about your team, and knowing that you may not be on the team forever. Dream teams are about performance, not seniority or tenure. It is up to the manager to ensure that every player is amazing at their position, plays effectively with others and is given new opportunities to develop. That’s how we keep winning the championship (entertaining the world). Unlike a sports team, as Netflix grows, the number of players also grows. We work to foster players from the development leagues so they can become the stars of tomorrow."
    },

    {
        alpha: "Expectations of Jobs",
        beta: "To strengthen our dream team, our managers use a “keeper test” for each of their people: if a team member was leaving for a similar role at another company, would the manager try to keep them? Those who do not pass the keeper test (i.e. their manager would not fight to keep them) are given a generous severance package so we can find someone even better for that position—making an even better dream team. Being on a dream team is the thrill of a professional lifetime, and team members are incredibly supportive of each other. This is why You make time to help colleagues across Netflix succeed is a valued behavior."
    },

    {
        alpha: "Jobs Profiles",
        beta: "Managers communicate frequently with each member of their team so surprises are rare. We also encourage employees to check in with their manager at any time by asking, “How hard would you work to change my mind if I were thinking of leaving?”"
    }

]