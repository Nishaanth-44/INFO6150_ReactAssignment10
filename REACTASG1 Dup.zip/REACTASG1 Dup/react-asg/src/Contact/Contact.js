import React from 'react';
import Card from './ContactCardComp';
import {data} from './ContactData';

function Contact() {
    return (
        <>
        <div><a href="./Home.js">Return To Home Page</a></div>
        <h1>This is Contact page</h1>
        {
        data.map((item) => {
            return (
                <Card {...item}></Card>
            )
        })
       }
        </>    
        )

}

export default Contact