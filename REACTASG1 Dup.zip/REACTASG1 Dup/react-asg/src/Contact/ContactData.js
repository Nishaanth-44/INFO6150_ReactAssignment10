export const data = [
    {
        alpha: "Contact our Leaderships",
        beta: "The thing we most value is working with talented people in highly creative and productive ways. That’s why our core philosophy is people over process, and why we try to bring great people together as a dream team. Of course, any growing business requires some process and structure. But with our people-first approach, we can be more flexible, creative and successful in everything we do."
    },

    {
        alpha: "Contact Netflix",
        beta: "We believe a company’s actual values are shown by whom they hire, reward or let go. Below are the specific behaviors and skills we care about most. If these values describe you, and the people you want to work with, you’re likely to thrive at Netflix."
    },

    {
        alpha: "Culture of Netflix",
        beta: "A dream team is one in which all of your colleagues are extraordinary at what they do and highly effective working together. Our version of a great workplace is not great perks, although we have many. It’s about investing in a dream team of talented people who are excited to pursue ambitious shared goals. On our dream team we encourage collaboration, share information and discourage politics. There’s lots of love and there are demanding peers. It’s exhilarating and how we learn the most, do our best work, improve the fastest and have the most fun."
    }

]