export const data = [
    {
        alpha: "Dream Team",
        beta: "Loyalty is great as a stabilizer. Employees with a strong track record at Netflix get leeway if their performance takes a temporary dip, or if they are in a new role. Similarly, we want employees to stick with Netflix through any short term dips the company may have. That said, we don’t believe in long-term allegiance to a stagnant company, or to an only-adequately-performing employee."
    },

    {
        alpha: "Freedom and Responsibility",
        beta: "At some companies, people ignore trash on the floor, leaving it for someone else to pick up. At other companies, people lean down to pick it up, just like they would at home. We try hard to be a company where everyone feels a sense of responsibility to make us better. Picking up the trash is a metaphor for taking care of problems, small and large, and never thinking “that’s someone else’s job.” Creating a sense of ownership helps this behavior come naturally."
    },

    {
        alpha: "Informed Captains",
        beta: "For every significant decision, we identify an informed captain of the ship who is an expert in their area. They are responsible for listening to other people’s views and then making a judgment call on the right way forward. We avoid decisions by committee, which would slow us down and diffuse responsibility. It is sometimes challenging and always important to agree up front who is the informed captain for a project."
    }

]