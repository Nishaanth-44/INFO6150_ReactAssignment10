import React from 'react';

class Card extends React.Component {
    render() {
     console.log(this.props);
        return (
            <div class="card text-center">
            <div class="card-header">
              <h3>{this.props.alpha}</h3>
            </div>
            <div class="card-body">
              <p class="card-text">{this.props.beta}</p>
            </div>
          </div>
        );
    }
}
export default Card