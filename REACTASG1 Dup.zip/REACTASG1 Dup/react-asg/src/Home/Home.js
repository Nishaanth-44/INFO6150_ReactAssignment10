import React from 'react'
import Card from './HomeCardComp';
import {data} from './HomeData';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
// import AboutUs from '../AboutUs/AboutUs';
// import Contact from '../Contact/Contact';
// import Jobs from '../Jobs/Jobs';

function Home() {
    return (
       <><a href="./AboutUs.js">About Us  ||</a>
       <a href="./Contact.js"> Contact  ||</a>
       <a href="./Jobs.js">  Jobs</a>
       {
        data.map((item) => {
            return (
                <Card {...item}></Card>
            )
        })
       }
       
       </>


    )
}
export default Home