var express = require('express');
var router = express.Router();
const bcrypt = require('bcrypt');
var user=require('../models/user.models');
const jwt = require("jsonwebtoken");
const { json } = require('express');
const JWT_SECRET = "jednwfwquheufhque378ryedhuqleflqefkjwnefkjweufhuwhe34r298dhrjewbdhwbel";


router.post('/add', function(req, res, next) {
  let newUserDetails = new user({...req.body});
  newUserDetails.save(function(err, newUser){
    if(err){
      res.send({message: err.message})
    }else{
      res.setHeader('Content-Type', 'application/json');
      res.send({message:'Saved User Details Sucessfully', newUserObj :  newUserDetails});
    }
  });
});

router.post("/login-user", async function(req,res) {
  const { email, password } = req.body;

  const User = await user.findOne({email});
  if(!User) {
    return res.json({ error: "User not found!!"});
  }
  if(await bcrypt.compare(password, User.password)){
    const token = jwt.sign({}, JWT_SECRET);

    if(res.status(201)){
      return res.json({ status: "ok", data: token});
    } else{
      return res.json({ status: "error" });
    }
  }
  res.json({ status: "error", error: "Invalid Password!!! Please check your password"});

})

router.get('/getAll',async function(req, res, next) {
  try{
    let usersDetails = await user.find();
    res.send({message:'Successfully Retrived User Details', users :  usersDetails});
  }catch(err){
    console.log(err);
    res.send({message:'User retrive failed', error :  err.value});
  }
});

router.put('/edit', async function(req, res, next) {
  try{
    const userUpdated = req.body;
    let editUser = await user.where("email").equals(userUpdated.email).findOne();
    if(editUser != null){
      editUser.fullname = userUpdated.fullname;
      editUser.password = userUpdated.password;
    }else{
      res.send({message: "User with the provided email ID is not available, please check the email and try again." , userUpdated});
    }
    await editUser.save();
    res.send(editUser);
  }catch(err){
    res.send({message: err.message});
  }
});

router.delete('/delete', async function(req, res, next) {
  try{
    console.log(req.query.email)
    const userEmail = req.query.email;
    let dltUser = await user.where("email").equals(userEmail).deleteOne();
    res.send({message: "Deleted the User Successfully", dltUser});
  }catch(err){
    res.send({message: "Deletion of the User Failed"});
  }
});
module.exports = router;