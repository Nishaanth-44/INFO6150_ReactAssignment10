module.exports={
    DB_URL : "mongodb://localhost:27017/test?retryWrites=true&w=majority"
}
